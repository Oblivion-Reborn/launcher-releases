=================================
 INFO
=================================
UE4SS v3.0.1-394-g437a8ff with optional setup for Oblivion Remastered.
NOTE: this is a slimmed runtime version for END users!

UE4Ss is an injectable LUA scripting system, SDK generator, live property editor and other dumping utilities for UE4/5 games
See: https://github.com/UE4SS-RE/RE-UE4SS/blob/main/README.md

=================================
 INSTALL
=================================
STEAM:
1a. Go to your Steam Library, find "Oblivion Remastered", right-click,
    Manage -> Browse Local Files. This is your <GAME_ROOT> folder>.
    (i.e. "C:\Steam\steamapps\common\Oblivion Remastered")
2a. Extract content of the zip-archive inside the folder 
    "<GAME_ROOT>\OblivionRemastered\Binaries\Win64\"
GAMEPASS:
1b.  Find "XboxGames" folder on one of your drives.
    <GAME_ROOT> folder will be something like
    "C:\XboxGames\The Elder Scrolls IV- Oblivion Remastered\"
2b. Extract content of the zip-archive inside the folder 
    "<GAME_ROOT>\OblivionRemastered\Binaries\WinGDK\"

3.  Validate that file "dwmapi.dll" is in the same folder as "OblivionRemastered-Win*-Shipping.exe"
3a. OPTIONAL: Install UE4SS Signatures (only if you need it!)
4.  Installation complete


EXAMPLE:
The game is installed into:
d:\Steam\steamapps\common\Oblivion Remastered -- this is your <root_game_folder>
So you download the mod ZIP file, right click on it, select "Extract All"
and choose 
d:\Steam\steamapps\common\Oblivion Remastered\OblivionRemastered\Binaries\Win64\

In the end, your folder structure should be similar to this:
-----------------------
D3D12\
ue4ss\
dwmapi.dll
<...>
OblivionRemastered-Win64-Shipping.exe
-----------------------

=================================
 UNINSTALL
=================================
Delete file "dwmapi.dll" and "ue4ss\" folder. 
WARNING: Vortex DOES NOT delete it properly!


=================================
 GETTING STARTED WITH UE4SS
=================================
https://docs.ue4ss.com


=================================
 CONFLICTS
=================================
Other modloaders


=================================
 TROUBLESHOOTING
=================================
Before making a bug report:
1. Collect latest log file RIGHT AFTER the crash or an issue in:
   steam:  <GAME_ROOT>\OblivionRemastered\Binaries\Win64\ue4ss\UE4SS.log
   g-pass: <GAME_ROOT>\OblivionRemastered\Binaries\WinGDK\ue4ss\UE4SS.log)
2. Ensure that you have a latest "crash_2025-*.dmp" file in "ue4ss/" folder (only for the case of crash)
3. Remove all the mods except "BPML_GenericFunctions", "BPModLoaderMod" and "shared"
5. Repeat the crash - does it still happen on vanilla UE4SS with no extra mods?
6. If it does, collect the aforementioned log and crash dump file and submit an issue to
   https://github.com/UE4SS-RE/RE-UE4SS/issues
7. IMPORTANT: If the crash only happens with SPECIFIC user mod  - submit report to the MOD AUTHOR.


=================================
 UE4SS CONFIGURATION
=================================
For performance reasons,
  HookEngineTick
  HookGameViewportClientTick
are disabled.

For OBRE compatibility reasons, the default mods:
  CheatManagerEnablerMod
  ConsoleCommandsMod
  ConsoleEnablerMod
  LineTracer
  ActorDumperMod
  jsbLuaProfilerMod
  SplitScreenMod
  Keybinds

are removed because they serve no purpose to OBRE.
Use zDev verison from hithub if you need examples.


=================================
 UE4SS CONFIGURATION
=================================
- v0.1.0 - MANDATORY UPDATE: "mods.txt" converted from UTF8-BOM to ANSI to address issues with mod list read
         - updated optional BPModLoaderMod (not yet included, see "Optional files")
- v0.0.9 - NOT AN UPDATE - simply changed ZIP compression method
- v0.0.8 - NOT AN UPDATE - faked the verion as an attempt to shut up Vortex auto-update
- v0.0.7 - simplified the UE4SS for runtime-only needs for END USER:
         - removed irrelevant mods
         - added PDB to get crash call-stack for error reporting
         - expanded [TROUBLESHOOTING] section
- v0.0.6 - updated installation instruction for GAMEPASS
- v0.0.5 - disabled Console Mods
- v0.0.4 - oblivion remastered
- v0.3 - split signatures and main UE4SS installation
- v0.2 - added ability to choose which sig to use with a simple edit
- v0.1 - updated FText sig for 0.7.13


=================================
 CREDITS
=================================
UE4SS Team